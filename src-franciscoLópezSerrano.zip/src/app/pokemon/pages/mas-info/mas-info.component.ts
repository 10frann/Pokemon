import { Component } from '@angular/core';

@Component({
  selector: 'app-mas-info',
  templateUrl: './mas-info.component.html',
  styleUrl: './mas-info.component.css'
})
export class MasInfoComponent {

}
